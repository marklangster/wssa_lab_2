#include <Arduino.h>

#include <FreeRTOS_ARM.h>

extern "C" {
/**
 *  Print file and line when configASSERT is defied like this.
 *
 * #define configASSERT( x ) if( ( x ) == 0 ) {assertMsg(__FILE__,__LINE__);}
 */
void assertBlink();
void assertMsg(const char* file, int line) {
    interrupts();
    SerialUSB.print(pcTaskGetTaskName(NULL));
    SerialUSB.print(".");
    SerialUSB.print(file);
    SerialUSB.write('.');
    SerialUSB.println(line);
    SerialUSB.flush();
    noInterrupts();
    assertBlink();
    for (;;) {}
}
}  // extern "C"